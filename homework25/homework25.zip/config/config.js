module.exports = {
    mysql:{
        options:{
            host:'localhost',
            port:3306,
            database:'myBlog',
            dialect:'mysql',
            username:'root',
            password:'123456'
        }
    }
}