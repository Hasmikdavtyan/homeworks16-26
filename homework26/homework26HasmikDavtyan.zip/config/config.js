module.exports = {
    mysql:{
        options:{
            host:'localhost',
            port:3306,
            database:'homework1',
            dialect:'mysql',
            username:'root',
            password:'123456'
        }
    }
}